import '../../../core/app_export.dart';
import 'userprofilelist_item_model.dart';

class FriendLeaderboardYesterdaySModel {
  List<UserprofilelistItemModel> userprofilelistItemList = [
    UserprofilelistItemModel(usernameText: "Username", songText: "Song Name")
  ];
}
