import '../../../core/app_export.dart';
import 'userprofilesection_item_model.dart';

class FriendLeaderboardAllTimeModel {
  List<UserprofilesectionItemModel> userprofilesectionItemList = [
    UserprofilesectionItemModel(
        dynamicText: "#1", dynamicText1: "Username", dynamicText2: "Song Name")
  ];
}
